const request = require('postman-request')

const  licencecode = require('./licencecode')
const mastercode = require('./mastercode')
const doctocode = require('./doctocode')


const niveau =process.arg[3];
const formation=process.argv[2];
if( (!formation) && (!niveau) ){
    console.log('tapez une adresse et un niveau !')
}

else {

    if ( niveau>0 && niveau<4 ){
    licencecode(adresse,(error,data)=> {
        console.log(data)
        console.log(error)

    })
    } 

        else if ( niveau>3 && niveau<6 ){
            licencecode(adresse,(error,data)=> {
                console.log(data)
                console.log(error)
        
            })
        } 

        else if ( niveau>3 && niveau<6 ){
            mastercode(adresse,(error,data)=> {
                console.log(data)
                console.log(error)
        
            })
        } 
        else if ( niveau>5 && niveau<9 ){
            doctocode(adresse,(error,data)=> {
                console.log(data)
                console.log(error)
        
            })
        } 
}

console.log(process.arg)